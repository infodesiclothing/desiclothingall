select top 5 o.customer_id,FirstName, LastName, phone,email, sum(total) as total from customer c
inner join orders o on o.customer_id = c.customer_id
group by o.customer_id,FirstName, LastName, phone,email
order by total desc

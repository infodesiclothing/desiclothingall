insert into StoreCard values(1,1,10000,8000.0)
insert into StoreCard values(2,3,50000, 45000.00)
insert into StoreCard values(3,4,100000,80000.00)

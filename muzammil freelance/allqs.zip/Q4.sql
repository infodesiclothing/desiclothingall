ALTER TABLE StoreCard
ALTER column CardID INT NOT NULL;

alter table StoreCard
ADD PRIMARY KEY (CardID);